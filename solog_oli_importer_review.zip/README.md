# Solog OLI Migration Importer

Fondasi aplikasi web lokal untuk menyiapkan dan meninjau migrasi. Project ini terpisah dari repository Laravel Solog OLI.

## Status dan batas keselamatan

- Python yang didukung: `>=3.11,<3.14` (konfigurasi lokal saat dibuat: Python 3.13.3).
- Backend: FastAPI; template: Jinja2; HTMX disiapkan untuk interaksi halaman.
- Saat ini hanya ada dashboard placeholder dan endpoint health.
- Belum ada target database, konfigurasi database, SQL, workbook reader, mapping bisnis, atau Import Executor.
- Tidak ada koneksi ke database Solog OLI.
- Tombol/area upload, batch dan validation report adalah placeholder, bukan fitur aktif.

## Persyaratan

- Python 3.11 atau 3.12 direkomendasikan; Python 3.13 dapat digunakan dengan dependency versions yang memenuhi batas di `pyproject.toml`.
- `pip` dan `venv`.

## Instalasi di Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
```

Jika menggunakan Python 3.13, ganti `py -3.11` dengan `py -3.13`.

## Menjalankan aplikasi

```powershell
uvicorn app.main:app --reload
```

Buka `http://127.0.0.1:8000/`. Health check tersedia di `http://127.0.0.1:8000/health`.

Untuk mengubah nama aplikasi atau environment, gunakan environment variables opsional `SOLOG_IMPORTER_APP_NAME` dan `SOLOG_IMPORTER_ENVIRONMENT`. Logging level dapat diatur dengan `SOLOG_IMPORTER_LOG_LEVEL`. Jangan menaruh secret pada config/log. Aplikasi belum membaca `.env`.

## Menjalankan test

```powershell
python -m pytest
```

Test menggunakan FastAPI TestClient dan tidak mengakses database atau workbook.

## Struktur saat ini dan ekstensi mendatang

`app/` memuat entry point, config, logging, router health, template Jinja2, dan static CSS. `tests/` memuat test HTTP dasar. Modul Workbook Reader, Layout Detector, Data Normalizer, Mapping Engine, Transformation Engine, Master Resolver, Validation Engine, Preview, Dry-Run, dan Reconciliation direncanakan untuk tahap berikutnya setelah mapping/aturan disetujui. Import Executor secara eksplisit belum dibuat.

## Keputusan teknis yang belum ditentukan

- Versi Python/runtime final dan strategi environment deployment lokal.
- Sumber/hosting HTMX untuk penggunaan offline (dashboard memuat HTMX dari CDN; fungsi interaktif belum digunakan).
- Kebijakan autentikasi lokal, CORS, host binding dan CSRF sebelum fitur menerima file.
- Batas ukuran/retensi file upload, sanitasi output, penyimpanan workbook dan laporan.
- Local application state/crosswalk store—belum dibuat database state.
- Target database import, credential mechanism, privilege, schema version, backup dan rollback.
- Format mapping JSON final serta approval workflow.
- Kebijakan logging/retensi dan perlindungan data workbook.

Semua keputusan bisnis dan mapping tetap tunduk pada dokumen Stage 3.2 dan Stage 4.1 di repository Solog OLI.
