from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime settings for the local importer UI; deliberately has no DB settings."""

    app_name: str = "Solog OLI Migration Importer"
    environment: str = "local"
    debug: bool = False

    model_config = SettingsConfigDict(
        env_prefix="SOLOG_IMPORTER_",
        env_file=None,
        extra="ignore",
    )


settings = Settings()
